#include <iostream>
using namespace std;

int main() {
    const int MAX = 100;
    cout << "Value of MAX is: " << MAX << endl;

    return 0;
}
