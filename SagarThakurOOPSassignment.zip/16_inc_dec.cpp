#include <iostream>
using namespace std;

int main() {
    int a = 10;
     cout << "Original: " << a << endl;
     cout << "Post-increment (a++): " << a++ << endl;
     cout << "After post-increment: " << a << endl;
     cout << "Pre-increment (++a): " << ++a << endl;

     cout << "Post-decrement (a--): " << a-- << endl;
     cout << "After post-decrement: " << a << endl;
     cout << "Pre-decrement (--a): " << --a << endl;

    return 0;
}
