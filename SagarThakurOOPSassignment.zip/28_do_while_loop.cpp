#include <iostream>
using namespace std;

int main() {
    int i = 1;

    cout << "Printing numbers from 1 to 5 using do-while:" << endl;
    do {
        cout << i << endl;
        i++;
    } while (i <= 5);

    return 0;
}
