#include <iostream>
using namespace std;

int main() {
    int n, i;
    cout << "Enter value of n: ";
    cin >> n;

    cout << "Series: ";
    for(i = 1; i <= n; i++) {
        cout << i << " ";
    }

    return 0;
}
