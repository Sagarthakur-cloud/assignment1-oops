#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num > 10) {
        cout << "Number is greater than 10" << endl;
    }

    cout << "Program ended." << endl;
    return 0;
}
